/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/15 12:20 PM
 */

import chai from 'chai';

import TableEngine from '../TableEngine';
import { Andy, Bill, James } from './fixture/user';
import ApiConfig from '../constant/ApiConfig';

import createRoomette from './helper/createRoomette';
import setGameRule from "./helper/setGameRule";
import setRoometteRule from "./helper/setRoometteRule";
import setTableRule from "./helper/setTableRule";
import setAllRules from './helper/setAllRules';
import setRoometteRuleAddTime from './helper/setRoomTime';
import assertEmptyObject from './helper/assertEmptyObject';

const expect = chai.expect;

describe('RemoteRoomette', () => {
    let andyRemoteRoomette;
    let billRemoteRoomette;
    let jamesRemoteRoomette;
    beforeAll(() => {
        const andyTableEngine = new TableEngine(ApiConfig.host, Andy.accessToken);
        andyRemoteRoomette = andyTableEngine.getRemoteRoomette();
        const billTableEngine = new TableEngine(ApiConfig.host, Bill.accessToken);
        billRemoteRoomette = billTableEngine.getRemoteRoomette();
        const jamesTableEngine = new TableEngine(ApiConfig.host, James.accessToken);
        jamesRemoteRoomette = jamesTableEngine.getRemoteRoomette();
    });
    describe('when create and close roomette', () => {
        let roometteId;
        it('should create roomette, success', () => {
            return createRoomette().then((res) => {
                expect(res).to.be.a('object').and.have.property('roomette_id');
                roometteId = res.roomette_id;
            });
        });
        it('should set game rule, success', () => {
            return setGameRule(roometteId).then((res) =>{
                expect(res).to.have.property('bet_rule');
                expect(res).to.have.property('choose_dealer_rule');
                expect(res).to.have.property('deck_rule');  
                expect(res).to.have.property('double_rule');
                expect(res).to.have.property('insurance_rule');
                expect(res).to.have.property('split_rule');
            });
        });
        it('should set roomette timerule, success', () => {
            return setRoometteRuleAddTime(roometteId).then((res) => {
                expect(res).to.have.property('add_second');
            });
        });
        it('should set roomette rule, success', () => {
            return setRoometteRule(roometteId).then((res) => {
                expect(res).to.have.property('roomette');
                expect(res).to.have.property('roomette_timer');
            })
        });

        it('should set table rule, success', () => {
            return setTableRule(roometteId).then((res) => {
                expect(res).to.have.property('seat_reserve_rule');
                expect(res).to.have.property('stack_range');
                expect(res).to.have.property('table');
                expect(res).to.have.property('table_sit_down_rule');
                expect(res).to.have.property('table_stand_up_rule');
            })
        });
        it('should close roomette, success', () => {
            return andyRemoteRoomette.close(Andy.id, roometteId).then((res) => {
                expect(res).to.have.property('user_id');
                expect(res).to.have.property('roomette_id');
            });
        });
    });
    describe('when start a game', () => {
        let roometteId;
        beforeAll(() => {
            return createRoomette().then((res) => {
                const { roomette_id: id } = res;
                roometteId = id;
                return setAllRules(id);
            });
        });
        afterAll(() => {
            return andyRemoteRoomette.close(Andy.id, roometteId);
        });
        describe('when player enter roomette', () => {
            it('should user1 enter, success', () => {
                return andyRemoteRoomette.playerEnter(roometteId).then((res) => {
                    expect(res).to.have.property('user_id');
                    expect(res).to.have.property('roomette_id');
                });
            });
            it('should user2 enter, success', () => {
                return billRemoteRoomette.playerEnter(roometteId).then((res) => {
                    expect(res).to.have.property('user_id');
                    expect(res).to.have.property('roomette_id');
                });
            });
            it('should user3 enter, success', () => {
                return jamesRemoteRoomette.playerEnter(roometteId).then((res) => {
                    expect(res).to.have.property('user_id');
                    expect(res).to.have.property('roomette_id');
                });
            });
        });
        describe('when query roomette information', () => {
            it('should query roomette status, success', () => {
                return andyRemoteRoomette.getStatus(roometteId).then((res) => {
                    assertEmptyObject(res);
                });
            });
            it('should query roomette rule, success', () => {
                return andyRemoteRoomette.getRule(roometteId).then((res) => {
                    assertEmptyObject(res);
                });
            });
        });
        describe('when user1 buy in', () => {
            it('should user1 deposit chip, success', () => {
                const depositChipAmount = 1000;
                return andyRemoteRoomette.depositChip(roometteId, depositChipAmount).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('user_id');
                });
            });
        });
        describe('when user2 buy in', () => {
            it('should user2 deposit chip, success', () => {
                const depositChipAmount = 1000;
                return billRemoteRoomette.depositChip(roometteId, depositChipAmount).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('user_id');
                });
            });
        });
        describe('when user3 buy in', () => {
            it('should user3 deposit chip, success', () => {
                const depositChipAmount = 1000;
                return jamesRemoteRoomette.depositChip(roometteId, depositChipAmount).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('user_id');
                });
            });
        });
        describe('when users sit', () => {
            it('should user sit on a not exist seat, fail', () => {
                const seatNumber = 5;
                return andyRemoteRoomette.playerSitOnSeat(roometteId, seatNumber).catch((error) => {
                    expect(error.message).to.be.equal('Seat not exist');
                });
            });
            it('should user1 sit on a exist seat, success', () => {
                const seatNumber = 3;
                return andyRemoteRoomette.playerSitOnSeat(roometteId, seatNumber).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('seat_number');
                    expect(res).to.have.property('user_id');
                });
            });
            it('should user2 sit on a exist seat, success', () => {
                const seatNumber = 2;
                return billRemoteRoomette.playerSitOnSeat(roometteId, seatNumber).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('seat_number');
                    expect(res).to.have.property('user_id');
                });
            });
            it('should user 3 sit on a system allocate seat, success', () => {
                return jamesRemoteRoomette.playerSitOnSystemAllocateSeat(roometteId).then((res) => {
                    expect(res).to.have.property('roomette_id');
                    expect(res).to.have.property('seat_number');
                    expect(res).to.have.property('user_id');
                });
            });
        });
        let roundId;
        describe('when make roomette ready', () => {
            it('should start timer, success', () => {
                return andyRemoteRoomette.startTimer(roometteId).then((res) => {
                    expect(res).to.have.property('roomette_timer_is_running');
                });
            });
            it('should create round, success', () => {
                return andyRemoteRoomette.createRound(roometteId).then((res) => {
                    expect(res).to.have.property('round_id');
                    const { round_id: id } = res;
                    expect(id).to.not.equal(null);
                    expect(id).to.not.equal(undefined);
                    roundId = id;
                });
            });
        });
        describe('when users ready', () => {
            it('should ready start, success', () => {
                return andyRemoteRoomette.playerReadyStart(roometteId, roundId).then((res) => {
                    expect(res).to.have.property('ready_seconds');
                });
            });
            it('should user1 ready, success', () => {
                return andyRemoteRoomette.playerReady(roometteId, roundId).then((res) => {
                    expect(res).to.have.property('user_id');
                });
            });
            it('should user2 ready, success', () => {
                return billRemoteRoomette.playerReady(roometteId, roundId).then((res) => {
                    expect(res).to.have.property('user_id');
                });
            });
        });
        describe('when player stand up', () => {
            it('should player stand up, success', () => {
                return andyRemoteRoomette.playerStandUp(roometteId).then((res) => {
                    expect(res).to.have.property('player_id');
                });
            });
        });
        describe('when add roomette duration', () => {
            it('should creator add roomette duration, success', () => {
                const second = 200;
                return andyRemoteRoomette.addDuration(second, roometteId).then((res) => {
                    expect(res).to.have.property('add_second');
                });
            });
            it('should others user add roomette duration, fail', () => {
                const second = 200;
                return andyRemoteRoomette.addDuration(second, roometteId).catch((error) => {
                    expect(error.message).to.equal('Player is not administrator');
                });
            });
        });
    });
});
