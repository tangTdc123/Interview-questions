/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2022/4/26 5:23 PM
 */

import TableEngine from "../../TableEngine";
import ApiConfig from "../../constant/ApiConfig";
import {Andy} from "../fixture/user";
import roometteRule from '../fixture/roometteRule';

const setRoometteRule = (roometteId) => {
    const tableEngine = new TableEngine(ApiConfig.host, Andy.accessToken);
    const remoteRoomette = tableEngine.getRemoteRoomette()
    return remoteRoomette.setRoometteRule(roometteId, roometteRule);
};

export default setRoometteRule;
