/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/26 1:42 PM
 */


import setGameRule from "./setGameRule";
import setRoometteRule from "./setRoometteRule";
import setTableRule from "./setTableRule";

const setAllRules = (roometteId) => {
    return setGameRule(roometteId).then(() => {
        return setRoometteRule(roometteId).then(() => {
            return setTableRule(roometteId);
        });
    });
};

export default setAllRules;
