import TableEngine from "../../TableEngine";
import ApiConfig from "../../constant/ApiConfig";
import {Andy} from "../fixture/user";
import roometteRule from '../fixture/roometteRule';

const setRoometteRuleAddTime = (roometteId) => {
    const tableEngine = new TableEngine(ApiConfig.host, Andy.accessToken);
    const remoteRoomette = tableEngine.getRemoteRoomette()
    return remoteRoomette.setRoometteRuleAddTime(roometteId, roometteRule);
};

export default setRoometteRuleAddTime;
