/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/17 2:22 PM
 */

import chai from 'chai';

const should = chai.should();

export default function assertEmptyObject(res) {
    Object.keys(res).should.have.lengthOf(0);
}
