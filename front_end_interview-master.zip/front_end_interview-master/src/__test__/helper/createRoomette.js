/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/26 1:36 PM
 */
import { Andy } from '../fixture/user';
import TableEngine from '../../TableEngine';
import ApiConfig from '../../constant/ApiConfig';

const createRoomette = () => {
    const tableEngine = new TableEngine(ApiConfig.host, Andy.accessToken);
    const remoteRoomette = tableEngine.getRemoteRoomette();
    return remoteRoomette.createRoomette(Andy.id);
};

export default createRoomette;
