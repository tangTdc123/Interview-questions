/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2022/4/26 10:40 AM
 */

import { MAX_BUY_IN, MIN_BUY_IN } from './buyIn';

const tableRule = {
    isReserveSeat: true,
    seatReserveSeconds: 60,
    reachedUserNumber: 2,
    sitDownMinimumStack: 100,
    buyInRangeMaximum: MAX_BUY_IN,
    standUpMinimumStack: 50,
    operatingSeconds: 3,
    seatQuantity: 4,
    minimumStack: MIN_BUY_IN,
    maximumStack: MAX_BUY_IN,
};

export default tableRule;
