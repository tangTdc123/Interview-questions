/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/26 1:47 PM
 */

export const MIN_BUY_IN = 100;
export const MAX_BUY_IN = 300;
