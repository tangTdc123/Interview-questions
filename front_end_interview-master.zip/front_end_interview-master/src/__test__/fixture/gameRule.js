/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2022/4/26 10:40 AM
 */

const gameRule = {
    deckAmount: 2,
    twoPlusCardsCanDouble: true,
    betSeconds: 5,
    insuranceSeconds: 10,
    splitRequiresPair: true,
    chooseDealerRule: 5,
    minBet: 100,
    maxBet: 300,
};

export default gameRule;
