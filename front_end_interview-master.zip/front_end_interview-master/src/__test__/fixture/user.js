/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/15 3:18 PM
 */

export const Andy = {
    username: '65535100000',
    nickname: 'TableEngineTest',
    id: 'a9e773c9-bbf6-42e7-8a27-7185761fcad8',
    accessToken: 'dTiRLGw7P8H7h4h9FxpKnyaqKYs0Cutk',
};

export const Bill = {
    username: '655351000001',
    nickname: 'Tiger',
    id: '837d54ef-6c5f-4510-8258-68fb2cc636ef',
    accessToken: 'Sq3HcEU2xb8d3itXozDTWijqsB7MNSKC',
};

export const James = {
    username: '655351000002',
    nickname: 'Super Star',
    id: '7d812cba-044d-4784-a6fb-57d9412c4ad5',
    accessToken: 'Wevwd8ZwNZT7QiYpv29XbayaUuXHqCqw',
};
