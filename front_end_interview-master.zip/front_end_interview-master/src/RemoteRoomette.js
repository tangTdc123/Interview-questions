/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/15 3:49 PM
 */

import RequestAbility from 'rn_request_ability';

import RequestAbilityHeaderFactory from './util/RequestAbilityHeaderFactory';
import ApiVersionEnum from './constant/ApiVersionEnum';
import ApiConfig from "./constant/ApiConfig";

export default class RemoteRoomette extends RequestAbility {
    /**
     * 创建一个房间
     * @param userId
     * @returns {Promise<* | void>}
     */
    createRoomette(userId) {
        const path = `/service/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette`;
        const body = {
            user_id: userId,
        };
        return this.put(path, {}, body);
    }

    /**
     * 设置房间游戏规则
     * @param roometteId 房间id
     * @param ruleData 规则数据
     */
    setGameRule(roometteId, ruleData) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/game_rule`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            deck_amount: ruleData.deckAmount,
            more_than_two_cards_can_double: ruleData.twoPlusCardsCanDouble,
            bet_seconds: ruleData.betSeconds,
            min_bet: ruleData.minBet,
            max_bet: ruleData.maxBet,
            insurance_seconds: ruleData.insuranceSeconds,
            must_be_a_pair_can_split: ruleData.splitRequiresPair,
            choose_dealer_seconds: ruleData.chooseDealerRule,
        };
        return this.put(path, header, body);
    }

    /**
     * 增加房间时间
     * @param roometteId
     * @param ruleData
     * @returns {Promise<* | void>}
     */
     setRoometteRuleAddTime(roometteId, ruleData){
        const path = `/v1/${ApiConfig.gameType}/roomette/${roometteId}/timer/second`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            second: ruleData.nextRoundStartSeconds,
        };
        return this.put(path, header, body);
        
    }


    /**
     * 设置房间的规则
     * @param roometteId
     * @param ruleData
     * @returns {Promise<* | void>}
     */
    setRoometteRule(roometteId, ruleData) {
        const path = `/v1/${ApiConfig.gameType}/roomette/${roometteId}/roomette_rule`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            roomette_title: ruleData.roometteTitle,
            seconds: ruleData.seconds,
        };
        return this.put(path, header, body);
    }


    /**
     * 设置房间table的规则
     * @param roometteId
     * @param ruleData
     * @returns {Promise<* | void>}
     */
    setTableRule(roometteId, ruleData) {
        const path = `/v1/${ApiConfig.gameType}/roomette/${roometteId}/table_rule`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            is_reserve_seat: ruleData.isReserveSeat,
            seat_reserve_seconds: ruleData.seatReserveSeconds,
            stand_up_minimum_stack: ruleData.standUpMinimumStack,
            sit_down_minimum_stack: ruleData.sitDownMinimumStack,
            seat_quantity: ruleData.seatQuantity,
            minimum_stack: ruleData.minimumStack,
            maximum_stack: ruleData.maximumStack,
        };
        return this.put(path, header, body);
    }

    /**
     * 玩家进入房间
     * @param roometteId 房间id
     */
    playerEnter(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/user/enter`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 房间开始计时
     * @param roometteId 房间id
     */
    startTimer(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/timer/start`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 查询房间状态
     * @param roometteId 房间id
     */
    getStatus(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/state`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 获取房间规则详情
     * @param roometteId
     */
    getRule(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/rule/query`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 把玩家金币转入房间
     * @param roometteId 房间id
     * @param transformAmount 转账数量
     */
    transformCoinIntoRoomette(roometteId, transformAmount) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/chip/deposit`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            amount: transformAmount,
        };
        return this.put(path, header, body);
    }

    /**
     * 把房间中金币存入Chip
     * @param roometteId 房间id
     * @param depositAmount 转账数量
     */
    depositChip(roometteId, depositAmount) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/chip/deposit`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        const body = {
            amount: depositAmount,
        };
        return this.put(path, header, body);
    }

    /**
     * 玩家坐到指定座位上
     * @param roometteId 房间id
     * @param seatNumber 座位号
     */
    playerSitOnSeat(roometteId, seatNumber) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/table/seat/${seatNumber}/sit_down`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 玩家站起
     * @param roometteId 房间id
     */
    playerStandUp(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/table/seat/stand_up`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 玩家坐下由系统分配座位，匹配的时候
     * @param roometteId 房间id
     * @returns {Promise<* | void>}
     */
    playerSitOnSystemAllocateSeat(roometteId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/table/seat/sit_down`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }

    /**
     * 关闭房间
     * @param userId 玩家id
     * @param roometteId 房间id
     */
    close(userId, roometteId) {
        const path = `/service/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/close`;
        const body = {
            user_id: userId,
        };
        return this.put(path, {}, body);
    }

    /**
     * 此方法为service util，客户端不会调用方法，这里只是方便前端测试能进行
     * @param roometteId
     */
    createRound(roometteId) {
        const path = `/service/v1/${ApiConfig.gameType}/roomette/${roometteId}/round`;
        return this.put(path, {});
    }

    /**
     * 此方法为service util，客户端不会调用方法，这里只是方便前端测试能进行
     * @param roometteId
     * @param roundId
     * @returns {Promise<* | void>}
     */
    playerReadyStart(roometteId, roundId) {
        const path = `/service/v1/${ApiConfig.gameType}/roomette/${roometteId}/round/${roundId}/ready/start`;
        return this.put(path, {});
    }

    /**
     * 玩家准备
     * @param roometteId 房间id
     * @param roundId
     */
    playerReady(roometteId, roundId) {
        const path = `/${ApiVersionEnum.V1}/${ApiConfig.gameType}/roomette/${roometteId}/round/${roundId}/player/ready`;
        const header = RequestAbilityHeaderFactory.authenticatedHeader(this.accessToken);
        return this.put(path, header, {});
    }
}
