/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/14 5:44 PM
 */

import RemoteRoomette from './RemoteRoomette';

export default class TableEngine {
    #apiHost;

    #accessToken;

    constructor(apiHost, accessToken) {
        this.#apiHost = apiHost;
        this.#accessToken = accessToken;
    }

    getRemoteRoomette() {
        return new RemoteRoomette(this.#apiHost, this.#accessToken);
    }
}
