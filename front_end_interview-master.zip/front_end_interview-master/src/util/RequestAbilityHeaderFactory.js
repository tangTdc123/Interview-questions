/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/11/17 4:16 PM
 */

export default class RequestAbilityHeaderFactory {
    static _header() {
        return {
            Accept: 'application/json',
            'Content-Type': 'application/json',
            APP_VERSION: 'bj_app_version',
            'APP-ID': 'laiwan',
            'Accept-Language': 'en',
        };
    }

    static notAuthenticatedHeader() {
        return this._header();
    }

    static authenticatedHeader(accessToken) {
        const header = this._header();
        Object.assign(header, {
            Authorization: `Bearer ${accessToken}`,
        });
        return header;
    }
}
