/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/15 3:08 PM
 */

export default class ApiConfig {
    static get host() {
        return 'https://64.kr-seoul.api.staging.laiwan.shafayouxi.com';
    }
    static get gameType() {
        return 'blackjack';
    }
}
