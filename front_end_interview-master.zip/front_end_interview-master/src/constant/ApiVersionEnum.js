/**
 * Copyright (c) 2018-present, SanQiu, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 * author：Mark
 * date：  2021/9/15 5:56 PM
 */

const ApiVersionEnum = Object.freeze({
    V1: 'v1',
    V2: 'v2',
    V3: 'v3',
});

export default ApiVersionEnum;
