WIFI: ppb_5G
WIFI密码: happyhour2021

项目介绍：
1. 搭建node开发环境并且记录搭建过程
2. 配置jest测试环境
2. 跑过项目中的所有测试（如果有无法跑过的测试，请自行修复）
3. 理解此项目的意图,用自己的话描述出项目具体做了什么
4. 指出项目的问题，并给出更优雅的实现（加分项）

提示：
1. 需要查阅的api文档在最下面
2. src/ 是项目的源代码文件夹
3. \__test\__ 是测试代码文件夹
4. npm test 是运行测试的快捷方式
5. 顺利运行测试成功之后，根据文档3，完成对获取用户Profile接口的测试以及实现


任务时长: 最长4h

PS: 测试中可以使用任何的通讯工具和搜索引擎来解决遇到的问题

## 1 设置房间游戏规则
**请求**: 

| 方法名 | 参数 | 描述 |
| --- | --- | --- |
| path | `/v1/<game_type>/roomette/<roomette_id>/game_rule` | - |
| method | `PUT` | - |
| header | `用户的Token` | eg：access_token |
| body | `deck_amount` | 牌堆的数量（int） |
| body | `more_than_two_cards_can_double` | 超过两张牌之后能否double（bool） |
| body | `bet_seconds` | 玩家用于下注的时间（int） |
| body | `min_bet` | 下注的最小金额（int） |
| body | `max_bet` | 下注的最大金额（int） |
| body | `insurance_seconds` | 购买保险的时间（int） |
| body | `must_be_a_pair_can_split` | 必须是对子才能分牌（bool） |
| body | `choose_dealer_seconds` | 玩家考虑是否成为庄家的时间（int） |

正常响应: 
```json
{
  "ok": true,
  "result": {
    "bet_rule": {
      "bet_range": {
        "max_bet": 1000,
        "min_bet": 10
      },
      "bet_seconds": 5
    },
    "choose_dealer_rule": {
      "choose_dealer_seconds": 10
    },
    "deck_rule": {
      "deck_amount": 3
    },
    "double_rule": {
      "can_more_than_two_cards": true
    },
    "insurance_rule": {
      "insurance_seconds": 10
    },
    "split_rule": {
      "must_need_twain": true
    }
  }
}
```
## 2 房间增加时间
**请求**: 

| 方法名 | 参数 | 描述 |
| --- | --- | --- |
| path | `/v1/<game_type>/roomette/<roomette_id>/timer/second` | - |
| method | `PUT` | - |
| header | `用户的Token` | eg：access_token |
| body | `second` | 增加的房间秒数 |

正常响应: 
```json
{
  "ok": true,
  "result": {
    "add_second": 30
  }
}
```
centrifugo下发给房间添加时间的消息: 
```json
{
  "channel": "roomette|ef362632-7571-4979-9fa6-4da270a8ea0b",
  "data": {
    "data": {
      "queue": [
        {
          "event": "roomette/add_seconds",
          "player": "11cc934a-d494-4d9b-be51-b953afbd9e32",
          "roomette_id": "ef362632-7571-4979-9fa6-4da270a8ea0b",
          "seconds": 30
        }
      ],
      "send_at": "2022-04-26T08:28:32.792704+00:00",
      "stream": "blackjack_table"
    }
  }
}
```

## 3 获取profile
**请求**: 

| 方法名 | 参数 | 描述 |
| - | - | - |
| path | `/v1/profile/<user_id>` | - |
| method | `GET` | - |

正确响应: 
```json
{
  "ok": true,
  "message": "",
  "result": {
    "nickname": "fakename",
    "user_id": "947167ab-0991-461a-938f-dc2a02c41b31",
    "avatar_path": null,
    "gender": null,
    "created_at": "2021-07-26T07:28:32.578000+00:00",
    "bio": null,
    "birthday": null
  }
}
```
