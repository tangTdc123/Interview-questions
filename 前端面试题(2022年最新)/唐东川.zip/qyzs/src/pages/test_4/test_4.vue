<template>
    <div class="test-content test4">
        <div class="left-require">
            <div>
                <img class="" src="../../statics/img/table-list.jpg" alt="">
                <h2>在右侧空白区域完成如图所示的表格,表格数据见参数table_data，不得使用其他插件或组件（包括elementUI）</h2>
                <h2>表格数据查询，根据查询条件筛选数组中的值，实现搜索功能</h2>
                <h2>性别列下拉筛选功能实现</h2>
                <h2>入学时间和毕业时间排序功能实现</h2>
                <h2 style="color: red">确认完成所有测试后需使用webpack将代码打包到文件夹dist</h2>
            </div>
        </div>

        <div class="right-content">
            <!--代码区域-->
        </div>
    </div>
</template>

<script>
//表格数据查询，根据查询条件筛选数组中的值，实现搜索功能
//下拉筛选功能实现
//排序功能实现
export default {
    name: "test_4",
    data(){
        return {
            //表格数据
            table_data:[
                {name: '张三',phone: '15222222222',sex: 'male', id: '510000000000000000',start_date: '2018-12-14 09:00',end_date: '2022-12-14 09:00'},
                {name: '李四',phone: '15221232222',sex: 'male', id: '510000000000000001',start_date: '2018-12-14 15:00',end_date: '2022-12-14 16:00'},
                {name: '韩梅梅',phone: '15222224562',sex: 'female', id: '51000000004500000',start_date: '2020-12-14 09:00',end_date: '2024-12-14 09:00'},
                {name: '李雷',phone: '15222662222',sex: 'male', id: '510000067000000000',start_date: '2017-12-14 09:00',end_date: '2020-12-14 09:00'},
                {name: '王雪',phone: '17822222222',sex: 'female', id: '515400004500000000',start_date: '2016-12-14 09:00',end_date: '2019-12-14 09:00'}
            ]
        }
    }
}
</script>

<style scoped>

</style>