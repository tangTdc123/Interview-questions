import Vue from 'vue';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import "../../statics/css/public.less";
import axios from 'axios';
import VueRouter from 'vue-router';
import store from '../../store/vue-store.js';
import Qs from 'qs';

Vue.use(VueRouter);
Vue.use(ElementUI);

let http = axios.create({
    transformRequest: [function (data) {
        return Qs.stringify(data)
    }]
});

import App from '../../pages/index/index.vue';
import test_1 from '../../pages/test_1/test_1.vue'

var  routes = [
    { path: '/', redirect: '/test_1'},
    { path: '/test_1', name:'test_1', component:test_1}
]

var  router = new VueRouter({
    routes
})

new Vue({
    el: "#main_manage",
    store,
    router,
    components: { App },
    template: '<App/>'
})