import Vue from 'vue'
import Vuex from 'vuex'
//vuex参数放在此处统一管理
Vue.use(Vuex);

const store = new Vuex.Store({
    state: {

    },
    mutations: {

    }
})

export default store