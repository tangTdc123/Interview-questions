<template>
    <div class="test-content">
        <div class="left-require">
            <div>
                <img src="../../statics/img/form-list.jpg" alt="">
                <h2>1、在右侧空白区域按照图片所示完成表单(可使用elementui)，并添加表单验证，点击保存时如果验证通过，将表单数据保存到vuex中</h2>
                <h2>2、在右侧空白区域以键值对的形似显示保存到vuex的数据</h2>
                <h2>3、给首页的 "跳转表单按钮" 添加点击事件，点击后可跳转到本页面，并读取上一次验证通过并保存到的vuex中的数据，显示到表单</h2>
                <h2>4、给身份证号码、电话号码添加正则验证，毕业时间需比入学时间晚3年</h2>
                <h2 style="color: red">确认完成所有测试后需使用webpack将代码打包到文件夹dist</h2>
            </div>
        </div>

        <div class="right-content">
            <!--代码区域-->
        </div>
    </div>
</template>

<script>
//测试一：
//1、按照图片完成表单，并添加表单验证，点击保存时如果验证通过，将表单数据保存到vuex中
//2、在右侧空白区域以键值对的形似显示保存到vuex的数据
//3、给首页的 "跳转表单按钮" 添加点击事件，点击后可跳转到本页面，并读取vuex中的数据，显示到表单
export default {
    name: "test_2",
    data(){
        return {

        }
    }
}
</script>

<style scoped>

</style>