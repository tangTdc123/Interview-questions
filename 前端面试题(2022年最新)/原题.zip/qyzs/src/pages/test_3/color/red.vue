<template>
    <div class="red">
        <span>{{num}}</span>
    </div>
</template>

<script>
export default {
    name: "red",
    data(){
        return {
            num:0
        }
    }
}
</script>

<style scoped>

</style>