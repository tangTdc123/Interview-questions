<template>
    <div id="main_manage" style="height: 100%;width: 100%">
        <div class="navigate">
            <router-link tag="div" to="/test_1">
                <span>测试一</span>
            </router-link>
            <div>测试二</div>
            <div>测试三</div>
            <div>测试四</div>
            <div>测试五</div>
        </div>
        <div class="content">
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
//按照如图所示的样式和顺序，完善路由配置
export default {
    components:{

    },
    data() {
        return {

        };
    },
    mounted() {

    },
    computed: {

    },
    watch: {

    },
    methods: {

    }
};
</script>

<style scoped>

</style>